#!/bin/sh

rm -rf lcmtest
